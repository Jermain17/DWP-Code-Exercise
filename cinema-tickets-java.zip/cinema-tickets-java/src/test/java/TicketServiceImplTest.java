import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import uk.gov.dwp.uc.pairtest.TicketService;
import uk.gov.dwp.uc.pairtest.TicketServiceImpl;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

import java.util.ArrayList;
import java.util.List;

public class TicketServiceImplTest {
    TicketService ticketService = new TicketServiceImpl();

    @Test
    public void testTicketPurchaseWithInvalidAccountId() {
        TicketTypeRequest[] ticketTypeRequests = new TicketTypeRequest[1];
        ticketTypeRequests[0] = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 1);
        try {
            ticketService.purchaseTickets((long) 0, ticketTypeRequests);
        } catch (InvalidPurchaseException e) {
            System.out.println("Rejected the ticket requests with exception: \n" + e);
        }
    }

    // dummy tickets means tickets with total no of tickets in all ticket request are zero
    @Test
    public void testDummyTickets() {
        TicketTypeRequest[] ticketTypeRequests = new TicketTypeRequest[3];
        ticketTypeRequests[0] = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 0);
        ticketTypeRequests[1] = new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 0);
        ticketTypeRequests[2] = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 0);
        try {
            ticketService.purchaseTickets((long) 1, ticketTypeRequests);
        } catch (InvalidPurchaseException e) {
            System.out.println("Rejected the ticket requests with exception: \n" + e);
        }
    }

    @Test
    public void testTicketRequestWithNoAdultTicket() {
        TicketTypeRequest[] ticketTypeRequests = new TicketTypeRequest[3];
        ticketTypeRequests[0] = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 0);
        ticketTypeRequests[1] = new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 3);
        ticketTypeRequests[2] = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 2);
        try {
            ticketService.purchaseTickets((long) 1, ticketTypeRequests);
        } catch (InvalidPurchaseException e) {
            System.out.println("Rejected the ticket requests with exception: \n" + e);
        }
    }

    @Test
    public void testSuccessfullTicketRequests() {
        TicketTypeRequest[] ticketTypeRequests = new TicketTypeRequest[3];
        ticketTypeRequests[0] = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 5);
        ticketTypeRequests[1] = new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 3);
        ticketTypeRequests[2] = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 2);
        try {
            ticketService.purchaseTickets((long) 1, ticketTypeRequests);
        } catch (InvalidPurchaseException e) {
            System.out.println("Rejected the ticket requests with exception: \n" + e);
        }
    }
}
