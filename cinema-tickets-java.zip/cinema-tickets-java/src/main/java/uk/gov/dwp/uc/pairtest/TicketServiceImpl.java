package uk.gov.dwp.uc.pairtest;

import thirdparty.paymentgateway.TicketPaymentService;
import thirdparty.paymentgateway.TicketPaymentServiceImpl;
import thirdparty.seatbooking.SeatReservationService;
import thirdparty.seatbooking.SeatReservationServiceImpl;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

public class TicketServiceImpl implements TicketService {
    /**
     * Should only have private methods other than the one below.
     */
    private final int ADULT_TICKET_PRICE = 20;
    private final int CHILD_TICKET_PRICE = 10;
    private final int INFANT_TICKET_PRICE = 0;
    private static TicketPaymentService ticketPaymentService = new TicketPaymentServiceImpl();
    private static SeatReservationService seatReservationService = new SeatReservationServiceImpl();

    @Override
    public void purchaseTickets(Long accountId, TicketTypeRequest... ticketTypeRequests) throws InvalidPurchaseException {
        boolean hasAdultTypeTicket = false;
        int noOfAdultTickets = 0;
        int noOfChildTickets = 0;
        int noOfInfantTickets = 0;

        if(accountId <= 0) {
            throw new InvalidPurchaseException("Invalid account Id");
        }

        // iterating through all ticket requests and calculating no of tickets of all three ticket types
        for(TicketTypeRequest ticketTypeRequest : ticketTypeRequests) {
            if(ticketTypeRequest.getTicketType() == TicketTypeRequest.Type.ADULT) {
                noOfAdultTickets += ticketTypeRequest.getNoOfTickets();
            } else if(ticketTypeRequest.getTicketType() == TicketTypeRequest.Type.CHILD) {
                noOfChildTickets += ticketTypeRequest.getNoOfTickets();
            } else {
                noOfInfantTickets += ticketTypeRequest.getNoOfTickets();
            }
        }

        // throwing exception if all ticketTypeRequest are coming with zero noOfTickets
        // as those are kind of dummy tickets and cannot book or make payment for them
        if( (noOfAdultTickets+noOfChildTickets+noOfInfantTickets) == 0) {
            throw new InvalidPurchaseException("No of tickets are zero");
        }

        // as per requirements doc, tickets cannot be purchased if no adult ticket is present in those ticket requests
        if(noOfAdultTickets == 0 ) {
            throw new InvalidPurchaseException("Child and Infant tickets cannot be purchased without purchasing an Adult ticket.");
        }

        int totalPrice = getTotalPrice(noOfAdultTickets, noOfChildTickets, noOfInfantTickets);
        int totalSeats = getTotalSeats(noOfAdultTickets, noOfChildTickets, noOfInfantTickets);

        if (!checkTotalTicketsUnderLimit(noOfAdultTickets, noOfChildTickets, noOfInfantTickets)) {
            throw new InvalidPurchaseException("Total tickets size exceeded limit 20 tickets");
        }

        // if all are good, then we go for seat reservation and payment
        bookSeats(accountId, totalSeats);
        makePayment(accountId, totalPrice);
    }

    private void makePayment(Long accountId, int totalPrice) {
        System.out.println("Confirming payment of " + totalPrice + " Please wait...\n") ;
        ticketPaymentService.makePayment(accountId, totalPrice);
        System.out.println("Payment is done and seat number details will be mailed to you.\nThank you Visit again!\n");
    }

    private void bookSeats(Long accountId, int totalSeats) {
        System.out.println("Selecting " + totalSeats +" tickets... Please wait...\n");
        seatReservationService.reserveSeat(accountId, totalSeats);
        System.out.println("Selected no of seats are available. Please make payment to confirm booking\n");
    }

    private boolean checkTotalTicketsUnderLimit(int noOfAdultTickets, int noOfChildTickets, int noOfInfantTickets) {
        // ignoring infant tickets here also, assuming infants are not given any ticket or seat and price is also 0
        return (noOfAdultTickets + noOfChildTickets) <= 20;
    }

    private int getTotalSeats(int noOfAdultTickets, int noOfChildTickets, int noOfInfantTickets) {
        // ignoring Infant tickets because infants need to sit on adult's lap. Seat will not be provided to them
        return noOfAdultTickets + noOfChildTickets;
    }

    private int getTotalPrice(int noOfAdultTickets, int noOfChildTickets, int noOfInfantTickets) {
        int totalPrice = 0;
        totalPrice += noOfAdultTickets * ADULT_TICKET_PRICE;
        totalPrice += noOfChildTickets * CHILD_TICKET_PRICE;
        // anyways infants ticket price is zero hence it will not affect in total price if we add it also like below
        totalPrice += noOfInfantTickets * INFANT_TICKET_PRICE;
        return totalPrice;
    }

}
